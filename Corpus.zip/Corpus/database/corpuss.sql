-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2018 at 05:39 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `corpuss`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `adminID` varchar(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(70) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phonenumb` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminID`, `username`, `password`, `email`, `phonenumb`) VALUES
('111111', 'admin1', '$2y$10$bTWSwUAMfFIFQM.ngUvMj.gqwoBHcKE.q.GWzfc2D/6./jNpDDr1S', 'admin1@gmail.com', 143147745),
('111113', 'admin3', '$2y$10$pFzbOhZEbgucKy4Ka7bdUeyZ5gfEgD6H.7G/j8e7arfg.OjlMVaju', 'admin3@gmail.com', 143147745),
('111114', 'admin4', '$2y$10$Mu1TQXeQSzZ545CJQO18zeECJpjB20w1eIKlt8US/AP1rbWcOp83a', 'admin4@gmail.com', 173147745);

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `commentID` varchar(10) NOT NULL,
  `userID` varchar(10) NOT NULL,
  `adminID` varchar(10) NOT NULL,
  `commlist` int(255) NOT NULL,
  `commdate` date NOT NULL,
  `answer` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `document`
--

CREATE TABLE IF NOT EXISTS `document` (
`id` int(30) NOT NULL,
  `name` varchar(100) NOT NULL,
  `year` int(4) NOT NULL,
  `topic` varchar(50) NOT NULL,
  `path` varchar(2000) NOT NULL,
  `date` date NOT NULL,
  `user_id` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

--
-- Dumping data for table `document`
--

INSERT INTO `document` (`id`, `name`, `year`, `topic`, `path`, `date`, `user_id`) VALUES
(43, 'set 1', 56778, '4', '../files/5c093926e55a62.27474980.pdf', '2018-12-06', ''),
(44, 'set 1', 56778, '4', '../files/5c093934caf172.54953222.pdf', '2018-12-06', ''),
(45, 'BITP 2213 SOFTWARE ENGINEERING SEM 2', 4536, '5', '../files/5c09393e29abc4.78019047.pdf', '2018-12-06', ''),
(46, 'BITP 2213 SOFTWARE ENGINEERING SEM 1', 4535, '5', '../files/5c096585cbe5b4.11448981.pdf', '2018-12-07', ''),
(47, 'tinie', 4554, '234234', '../files/5c09659e1fc918.65970953.pdf', '2018-12-07', ''),
(48, 'BITP 2213 SOFTWARE ENGINEERING SEM 1', 2010, '24', '../files/5c0965cc978475.84793858.pdf', '2018-12-07', ''),
(49, 'BITP 2213 SOFTWARE ENGINEERING SEM 2', 2016, '5', '../files/5c0965db7071b7.43158915.pdf', '2018-12-07', ''),
(50, 'BITP 2213 SOFTWARE ENGINEERING SEM 2', 2014, '4', '../files/5c0965ec55e4f3.27495084.pdf', '2018-12-07', '');

-- --------------------------------------------------------

--
-- Table structure for table `favourite`
--

CREATE TABLE IF NOT EXISTS `favourite` (
`id` int(30) NOT NULL,
  `user_id` int(15) NOT NULL,
  `doc_id` int(30) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `favourite`
--

INSERT INTO `favourite` (`id`, `user_id`, `doc_id`, `date`) VALUES
(12, 1, 18, '2018-11-26'),
(16, 1, 23, '2018-12-06'),
(17, 1, 28, '2018-12-06'),
(18, 1, 22, '2018-12-06'),
(19, 1, 35, '2018-12-06'),
(20, 1, 30, '2018-12-06'),
(21, 1, 33, '2018-12-06'),
(22, 1, 36, '2018-12-06'),
(23, 1, 34, '2018-12-06'),
(24, 1, 39, '2018-12-06'),
(25, 1, 43, '2018-12-07'),
(26, 1, 44, '2018-12-07'),
(27, 1, 45, '2018-12-07'),
(28, 1, 46, '2018-12-07'),
(29, 1, 47, '2018-12-07');

-- --------------------------------------------------------

--
-- Table structure for table `graph`
--

CREATE TABLE IF NOT EXISTS `graph` (
`id` int(30) NOT NULL,
  `set_name` varchar(50) NOT NULL,
  `lecture_7` int(30) NOT NULL,
  `lecture_8` int(30) NOT NULL,
  `lecture_9` int(30) NOT NULL,
  `lecture_10` int(30) NOT NULL,
  `lecture_11` int(30) NOT NULL,
  `lecture_12` int(30) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `graph`
--

INSERT INTO `graph` (`id`, `set_name`, `lecture_7`, `lecture_8`, `lecture_9`, `lecture_10`, `lecture_11`, `lecture_12`) VALUES
(1, 'set 1', 4, 5, 7, 5, 5, 4),
(2, 'set 2', 4, 5, 5, 6, 5, 5),
(3, 'set 3', 4, 4, 8, 5, 4, 4),
(4, 'set 4', 5, 4, 6, 5, 4, 6);

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE IF NOT EXISTS `quiz` (
  `quizID` int(10) NOT NULL,
  `userID` varchar(10) NOT NULL,
  `username` varchar(15) NOT NULL,
  `marks` int(255) NOT NULL,
  `subtopic` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `topic`
--

CREATE TABLE IF NOT EXISTS `topic` (
  `id` int(30) NOT NULL,
  `name` varchar(70) NOT NULL,
  `question` int(100) NOT NULL,
  `topics` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `topic`
--

INSERT INTO `topic` (`id`, `name`, `question`, `topics`) VALUES
(1014, 'bitp', 1, '10'),
(1015, 'bitp', 2, '8');

-- --------------------------------------------------------

--
-- Table structure for table `topic2`
--

CREATE TABLE IF NOT EXISTS `topic2` (
  `id` int(70) NOT NULL,
  `name` varchar(200) NOT NULL,
  `question` int(30) NOT NULL,
  `topic` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `userID` varchar(10) NOT NULL,
  `username` varchar(15) NOT NULL,
  `fullname` varchar(70) DEFAULT NULL,
  `status` varchar(70) NOT NULL,
  `email` varchar(70) DEFAULT NULL,
  `phoneNumb` int(15) NOT NULL,
  `password` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userID`, `username`, `fullname`, `status`, `email`, `phoneNumb`, `password`) VALUES
('b031710077', 'dina', 'dina', 'FTMK', 'dina@gmail.com', 163147745, '$2y$10$isW4FzbAKW7E68Cm.LsPDu4jNa2NlO5cYvzn8eXNKTgv1/vlweBa6'),
('b031710087', 'zaquan', 'Muhammad Zaquan Adha', 'FKE', 'zaquan@yahoo.com', 193124465, '$2y$10$aZNGlKM7bNwCbcGsrob7QOQWApF5QKk0Jfgv7OXEAu9uukpR4h8fe'),
('b031710089', 'tini', 'tinie', 'FTMK', 'tiniekhairi26@gmail.com', 143147745, '$2y$10$6YnWASiWMwgUpD4ems5mVOlUNDMdnEtjzDbhUncDpBSUPzw5zkuV.'),
('b031710090', 'user', 'user', 'Teacher', 'user@gmail.com', 143147745, '$2y$10$Rxs64YsT2WrUPS3X48ybb.XyGIrtydOkvJBj47Gq9v0Ll0oAB4Qc.'),
('b031710091', 'fatin', 'Nur Fatin Nabilah binti Sharudin', 'FKEKK', 'fatin@gmail.com', 18, '$2y$10$OE8U0U2.X0yCoumX83aIJue3GZ22pnXLe0M8JZnOFiwx4u8NDD.tG'),
('b031710098', 'fatin', 'Nur Fatin Nabilah binti Sharudin', 'Trainer', 'fatin@gmail.com', 18, '$2y$10$5nEle5uLL/v4Vx7iqoKhIeIL0uhgpC3oefBl0BndpgQmlTAaRCeKm');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
 ADD PRIMARY KEY (`commentID`), ADD KEY `adminID` (`adminID`), ADD KEY `userID` (`userID`);

--
-- Indexes for table `document`
--
ALTER TABLE `document`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `favourite`
--
ALTER TABLE `favourite`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `graph`
--
ALTER TABLE `graph`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quiz`
--
ALTER TABLE `quiz`
 ADD PRIMARY KEY (`quizID`), ADD KEY `userID` (`userID`);

--
-- Indexes for table `topic`
--
ALTER TABLE `topic`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `topic2`
--
ALTER TABLE `topic2`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `document`
--
ALTER TABLE `document`
MODIFY `id` int(30) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `favourite`
--
ALTER TABLE `favourite`
MODIFY `id` int(30) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `graph`
--
ALTER TABLE `graph`
MODIFY `id` int(30) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
ADD CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`adminID`) REFERENCES `admin` (`adminID`),
ADD CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`);

--
-- Constraints for table `quiz`
--
ALTER TABLE `quiz`
ADD CONSTRAINT `quiz_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
