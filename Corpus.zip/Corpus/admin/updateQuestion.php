<?php
	include_once '../model/dbconfig.php';
	
	$encapsulate = array();
	if(isset($_POST['que']) && isset($_POST['slot']) && isset($_POST['ans']) && isset($_POST['id']))
	{
		$isSuccess = false;
		$queid = $_POST['id'];
		$que = $_POST['que'];
		$listAnswer = $_POST['slot'];
		$trueAnswer = $_POST['ans'];

		$sizeQuestion = sizeof($que);
		$sizeAllAnswer = sizeof($listAnswer);
		
		$arrayAnswerList = 0;

		$tempArray = array();
		for($i = 1; $i<$sizeQuestion+1 ; $i++)
		{
			$tempArray['id'] = $queid[$i-1];
			$tempArray['question'] = $que[$i-1];
			$listAnswerArray = array();
			for($j = 0 ; $j < 4 ; $j++)
			{
				
				$listAnswerArray[] = $listAnswer[$arrayAnswerList];
				$arrayAnswerList++;
			}
			$tempArray['answer'] = $listAnswerArray;
			$tempArray['trueAnswer'] = $trueAnswer[$i-1];
			$encapsulate[] = $tempArray;
		}

		for($k = 0 ; $k <$sizeQuestion ; $k++ )
		{
			$sql = "update quiz set que = ? , option1 = ?, option2 = ? , option3 = ? , option4 = ?, ans = ? where id = ?";
			$realID = $encapsulate[$k]['id'];
			$realQuestion = $encapsulate[$k]['question'];
			$realAns1 = $encapsulate[$k]['answer'][0];
			$realAns2 = $encapsulate[$k]['answer'][1];
			$realAns3 = $encapsulate[$k]['answer'][2];
			$realAns4 = $encapsulate[$k]['answer'][3];
			$realTrueAns = $encapsulate[$k]['trueAnswer'];

			$stmt = $con->prepare($sql);
			$stmt -> bind_param("sssssss",$realQuestion,$realAns1,$realAns2,$realAns3,$realAns4,$realTrueAns,$realID);

			if($stmt->execute())
			{
				$isSuccess = true;
			}
			else
			{
				$isSuccess = false;
			}
		}
		

		if($isSuccess)
		{
			echo '
					<script> 
					alert("Data Updated");
					window.location.href = "quiz1Admin.php";
					</script>';
		}

		//echo json_encode($encapsulate);

	}

	$conn->close();

?>