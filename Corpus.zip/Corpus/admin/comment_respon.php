<?php
  //session_start();
  //require 'session.php';
  include 'navbar.php';
  require '../model/db.php';
  //TIMEZONE MALAYSIA
  date_default_timezone_set("Asia/kuala_lumpur");

  $msg = $msgClass = '';
  $commentID = $_REQUEST['commentID'];

    $sql = "SELECT * FROM comment WHERE commentID='$commentID'";
    $result = mysqli_query($conn, $sql);
    mysqli_num_rows($result);
    $row = mysqli_fetch_assoc($result);                     	
?>

<div class="wrapper">
  <section class="section">
    <div class="container2">
      <?php if($msg != ''): ?>
        <div id="msgBox" class="card-panel <?php echo $msgClass; ?>">
          <span class="white-text"><?php echo $msg; ?></span>
        </div>
      <?php endif ?>
      <center><h5><div class="card-panel grey darken-3 white-text">
      <i class="fas fa-comment"></i> Comment </h5></center>
      <div class="divider"></div>
   
			<br>
			<br>
			
	       <div class="card">
          <div class="card-content">
            
            <b><span class="card-title center-align">User Comment</span></b>
            <div class="row">
              <div class="col-lg-6">
                  <label for="userID">User ID</label>
                  <input type="text" id="userID" value="<?php echo $row['userID'] ?>" readonly>
                  <textarea readonly><?php echo $row['commlist'] ?></textarea>
              </div>
            </div>
          </div>
        </div>
			
			<br>
			<br>
			
         <div class="card">
          <div class="card-content">
            
            <b><span class="card-title center-align">Admin Respond</span></b>
            <div class="row">
              <div class="col-lg-6">
                <form action="respon_submit.php" method="POST" enctype="multipart/form-data">
                  <textarea name="respon" required></textarea>
                  <input type="hidden" class="form-control" name="respondate" id="date/time" value="<?php echo date("Y-m-d h:i:sa") ?>">
                  <input type="hidden" name="commentID" value="<?php echo $commentID ?>">
                  <input type="hidden" id="userID" name="userID" value="<?php echo $row['userID'] ?>" readonly>
				  <br>
				  <br>
                  <center><input type="submit" button class="waves-effect waves-light btn blue" name="submit"></center></input>
                </form>
              </div>
            </div>
          </div>
        </div>
	
      
<?php
  mysqli_close($conn);
  include 'footer.php';
?>
