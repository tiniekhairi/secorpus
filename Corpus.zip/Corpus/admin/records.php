<?php
  session_start();
  require 'session.php';
  include 'navbar.php';
  require '../model/db.php';

  $msg = $msgClass = '';

?>
<div class="wrapper">
  <section class="section">
    <div class="container2">
      <?php if($msg != ''): ?>
        <div id="msgBox" class="card-panel <?php echo $msgClass; ?>">
          <span class="white-text"><?php echo $msg; ?></span>
        </div>
      <?php endif ?>
      <h5><div class="card-panel grey darken-3 white-text">
      <i class="fas fa-book"></i> Document Collection</h5>
      <div class="divider"></div>
      <br>

      <!-- Search field -->
      <div class="row">
        <div class="col s12 m6"></div>
        <div class="col s12 m6">
          <div class="input-field">
            <i class="material-icons prefix">search</i>
            <input type="text" id="search">
            <label for="search">Search</label>
          </div>
        </div>
      </div>
      <!-- Table list -->
      <table id="myTable" class="responsive-table highlight centered">
        <thead class="grey darken-3 white-text">
          <tr class="myHead">
            <th>#</th>
            <th>Id</th>
            <th>Upload Date</th>
            <th>Document Set</th>
            <th>Document Id</th>
            <th class="center-align">Status</th>
          </tr>
        </thead>
        <tbody>
          <?php
            $i = 1;
            $sql = "SELECT * FROM `record`";
            $result = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_array($result)):
          ?>
          <tr>
            <td><?php echo $i; $i++; ?></td>
            <td><?php echo $row['record_id']; ?></td>
            <td><?php echo $row['record_start']; ?></td>
            <td>
              <!-- Modal Structure -->
              <div id="<?php echo $row['record_id']; ?>" class="modal">
                <div class="modal-content">
                  <img class="responsive-img" src="<?php echo '../'.$row['record_item']; ?>" alt="test">
                </div>
              </div>
              <a class="modal-trigger"  href="<?php echo '#'.$row['record_id']; ?>">View</a>
            </td>
            <td><?php echo $row['locker_id']; ?></td>
            <td><?php echo $row['record_status']; ?></td>
          </tr>
          <?php endwhile ?>
        </tbody>
      </table>
    </div>
  </section>
</div>
<?php
  mysqli_close($conn);
  include 'footer.php';
?>
