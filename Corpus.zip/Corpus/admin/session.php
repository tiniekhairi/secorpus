<?php
  require '../model/db.php';

  if (!isset($_SESSION['adminID'])){
    header("Location: login.php");
  }
?>
