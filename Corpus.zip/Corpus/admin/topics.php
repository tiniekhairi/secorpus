<?php
  session_start();
 //require 'session.php';
  include 'navbar.php';
  require '../model/db.php';

  $msg = $msgClass = '';

  // Form handling
  if (filter_has_var(INPUT_POST, 'submit')) {
    // Get form data
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $username = mysqli_real_escape_string($conn, $_POST['set_name']);
    $lecture7 = mysqli_real_escape_string($conn, $_POST['lecture_7']);
    $lecture8 = mysqli_real_escape_string($conn, $_POST['lecture_8']);
    $lecture9 = mysqli_real_escape_string($conn, $_POST['lecture_9']);
    $lecture10 = mysqli_real_escape_string($conn, $_POST['lecture_10']);
    $lecture11 = mysqli_real_escape_string($conn, $_POST['lecture_11']);
    $lecture12 = mysqli_real_escape_string($conn, $_POST['lecture_12']);
    

    // Check if the input is empty
    if (!empty($id) && !empty($username) && !empty($lecture7) && !empty($lecture8) && !empty($lecture9) && !empty($lecture10) && !empty($lecture11) && !empty($lecture12)) {
      // pass
      $sql = "INSERT INTO `graph` (`id`, `set_name`, `lecture_7`, `lecture_8`, `lecture_9`, `lecture_10`, `lecture_11`, `lecture_12`)
      VALUES ('$id', '$username', '$lecture7', '$lecture8', '$lecture9', '$lecture10', '$lecture11', '$lecture12')";

      if (mysqli_query($conn, $sql)) {
        // Success
        $msg = "topics added";
        $msgClass = "green";
      } else {
        $msg = "Fail to add topics error: " . $sql . "<br>" . mysqli_error($conn);
        $msgClass = "red";
      }
    } else {
      // failed
      $msg = "Please fill in all fields";
      $msgClass = "red";
    }
  }

  // Delete form handling
  if (isset($_POST['delete'])) {
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $sql = "DELETE FROM `graph` WHERE `id`='$id'";

    if (mysqli_query($conn, $sql)) {
      $msg = "Delete Successfull";
      $msgClass = "green";
    } else {
      $msg = "Error deleting this data";
      $msgClass = "red";
    }
  }
?>
<div class="wrapper">
  <section class="section">
    <div class="container2">
      <?php if($msg != ''): ?>
        <div id="msgBox" class="card-panel <?php echo $msgClass; ?>">
          <span class="white-text"><?php echo $msg; ?></span>
        </div>
      <?php endif ?>
      <h5><div class="card-panel grey darken-3 white-text">
      <i class="fas fa-user"></i> Topic Record</h5>
      <div class="divider"></div>
      <br>
      <div class="row">
        <div class="col s12 m6">
          <a href="#addgraph" class="btn blue darken-2 modal-trigger">Add New Record</a>
        </div>
        <div class="col s12 m6">
          <div class="input-field">
            <i class="material-icons prefix">search</i>
            <input type="text" id="search">
            <label for="search">Search</label>
          </div>
        </div>
      </div>
      <!-- Record table list -->
      <table id="myTable" class="responsive-table highlight centered">
        <thead class="blue darken-2 white-text">
          <tr class="myHead">
            <th>Id</th>
            <th>Document Name</th>
            <th>Lecture 7</th>
            <th>Lecture 8</th>
            <th>Lecture 9</th>
            <th>Lecture 10</th>
            <th>Lecture 11</th>
            <th>Lecture 12</th>
            <th colspan="2">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php
            $i = 1;
            $sql = "SELECT * FROM `graph`";
            $result = mysqli_query($conn, $sql);

            while ($row = mysqli_fetch_array($result)):
          ?>
            <tr>
              <td><?php echo $row['id']; ?></td>
              <td><?php echo $row['set_name']; ?></td>
              <td><?php echo $row['lecture_7']; ?></td>
              <td><?php echo $row['lecture_8']; ?></td>
              <td><?php echo $row['lecture_9']; ?></td>
              <td><?php echo $row['lecture_10']; ?></td>
              <td><?php echo $row['lecture_11']; ?></td>
              <td><?php echo $row['lecture_12']; ?></td>
              <td>
                <a href='topics_edit.php?id=<?php echo $row['id']; ?>' class='btn1 blue-text tooltipped' data-position='right' data-tooltip='Edit'><i class='fas fa-pencil-alt'></i></a>
              </td>
              <td>
                <form method='POST' action='topic.php'>
                  <input type='hidden' name='id' value="<?php echo $row['id'];?>">
                  <button type='submit' onclick='return confirm(`Delete this topic <?php echo $row['id']; ?>?`);' name='delete' class='btn1 red-text tooltipped' data-position='top' data-tooltip='Delete'>
                    <i class='far fa-trash-alt'></i>
                  </button>
                </form>
              </td>
            </tr>
          <?php endwhile ?>
        </tbody>
      </table>
     
      <!-- Modal -->
      <!-- Add record modal -->
      <div id="addgraph" class="modal">
        <div class="modal-content">
          <h5>Add Record</h5>
          <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="row">
              <div class="input-field">
                <i class="material-icons prefix">credit_card</i>
                <input id="id" type="text" name="id">
                <label for="id">Id</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field">
                <i class="material-icons prefix">face</i>
                <input id="username" type="text" name="username">
                <label for="username">Document Name</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field">
                <i class="material-icons prefix">email</i>
                <input type="text" id="question" name="question">
                <label for="question">Lecture 7</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field">
                <i class="material-icons prefix">email</i>
                <input type="text" id="question" name="question">
                <label for="question">Lecture 8</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field">
                <i class="material-icons prefix">email</i>
                <input type="text" id="question" name="question">
                <label for="question">Lecture 9</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field">
                <i class="material-icons prefix">email</i>
                <input type="text" id="question" name="question">
                <label for="question">Lecture 10</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field">
                <i class="material-icons prefix">email</i>
                <input type="text" id="question" name="question">
                <label for="question">Lecture 11</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field">
                <i class="material-icons prefix">email</i>
                <input type="text" id="question" name="question">
                <label for="question">Lecture 12</label>
              </div>
            </div>
            
            <div class="center">
              <button type="submit" class="btn blue" name="submit">Add</button>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">Close</a>
        </div>
      </div>
    </div>
  </section>
</div>
<?php
  mysqli_close($conn);
  include 'footer.php';
?>
