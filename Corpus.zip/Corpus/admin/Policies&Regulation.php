<?php
  session_start();
  require 'session.php';
  include 'navbar.php';
  require '../model/db.php';

  $msg = $msgClass = '';

?>
<div class="wrapper">
  <section class="section">
    <div class="container2">
    <div class="row">
          
      <h5><div class="card-panel grey darken-3 white-text">
      <i class="fas fa-book"></i> Policies and Regulation</h5>
      <div class="divider"></div>
      <ul class="collection with-header z-depth-1">
      Our policies, regulations and other public documents are listed in alphabetical order below. All available documents are just for review purpose and plagiarize is forbidden. Regulations and policies may be initiated in one of the University's departments or committees, but all regulations and policies must be agreed formally. Please contact Faculty of Information Technology and Communication (FTMK) of Universiti Teknikal Malaysia Melaka (UTeM) for further information.
      <br></ul>

     
  </section>
</div>
<?php
  mysqli_close($conn);
  include 'footer.php';
?>
