<?php
session_start();
require 'session.php';
include 'navbar.php';
require '../model/dbconfig.php';

$msg = $msgClass = '';
$count = 0;
?>
<!DOCTYPE html>
<html>
	<head>

		<title>
		
		</title>
		<script type="text/javascript" src="../js/jquery-3.3.1.min.js"></script>
	</head>
	<body>
		<div class="wrapper">
			<section class="section">

				<div class="container2">
					<?php if($msg != ''): ?>
						<div id="msgBox" class="card-panel <?php echo $msgClass; ?>">
							<span class="white-text"><?php echo $msg; ?></span>
						</div>
					<?php endif ?>
					<div class="card-panel grey darken-3 white-text">
						<h5><i class="fas fa-book"></i> quiz admin</h5>
						<br>
					</div>
				</div>


				<?php 	
					if (isset($_POST['click']) || isset($_GET['start'])) {
						$count += 1 ;
						$c = $count;
						if(isset($_POST['userans'])) { 
							$userselected = $_POST['userans'];
							$fetchqry2 = "UPDATE `quiz` SET `userans`='$userselected' WHERE `id`=$c-1"; 
							$result2 = mysqli_query($con,$fetchqry2);
						}
					} else 
					{
						
						$count = 0;
					}

				?>

				<div class="bump">
					<center>
					<br>
					<form>
						<?php if($count==0){ ?>
							<button class="button" name="start" float="left">
								<span>alter quiz</span>
							</button> 
						<?php } ?>
					</form>
				</center>
				</div>



			 				
				<?php 
				if(isset($c)) {   
					$fetchqry = "SELECT * FROM quiz"; 
					$result=mysqli_query($con,$fetchqry);
					$num=mysqli_num_rows($result);
					
					echo '<form action="updateQuestion.php" method="post">';
					while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
					{
						echo '
								<h1>Question '.$count.'</h1> <input required type="text" name="que[]" value="'.$row['que'].'">
								<br><br>
								answer slot 1<input type="hidden" name="id[]" value ="'.$row['id'].'"><input required type="text" name="slot[]" value="'. $row['option1'].'">
								<br><br>
								answer slot 2<input required type="text" name="slot[]"value="'. $row['option2'].'">
								<br><br>
								answer slot 3<input required type="text" name="slot[]"value="'. $row['option3'].'">
								<br><br>
								answer slot 4<input required type="text" name="slot[]"value="'. $row['option4'].'">
								<br><br>
								true answer<input required type="text" name="ans[]" value="'.$row['ans'].'">
								<br><br>';
								
					  		

					  	$count++;	
					}
					echo '<input type="submit" value="UPDATE">';
					echo '</form>';
				}
		  		?>
			</section>

		</div>
	</body>

	
</html>