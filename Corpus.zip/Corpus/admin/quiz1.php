<?php
  session_start();
  require 'session.php';
  include 'navbar.php';
  require '../model/db.php';

  $msg = $msgClass = '';

?>

<div class="wrapper">
  <section class="section">
    <div class="container2">
      <?php if($msg != ''): ?>
        <div id="msgBox" class="card-panel <?php echo $msgClass; ?>">
          <span class="white-text"><?php echo $msg; ?></span>
        </div>
      <?php endif ?>
      <h5><div class="card-panel grey darken-3 white-text">
      <i class="fas fa-book"></i> Quiz & Comment </h5>
      <div class="divider"></div>
      <br>

<body>
<a href="quizadmin.php">
<td><br><center><button type="submit" class="waves-effect waves-light btn blue" name="quiz admin">Quiz Administration</button></center></br></td>
	
	<script type="text/javascript">
	var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
	document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
	</script>
	<script type="text/javascript">
	var pageTracker = _gat._getTracker("UA-68528-29");
	pageTracker._initData();
	pageTracker._trackPageview();
	</script>

</body>
  </section>
</div>

<?php
  mysqli_close($conn);
  include 'footer.php';
?>
