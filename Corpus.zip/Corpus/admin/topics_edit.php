<?php
  session_start();
  require 'session.php';
  include 'navbar.php';
  require '../model/db.php';

  $msg = $msgClass = '';

  // handle the get request base on user id
  if (isset($_REQUEST['id'])) {
    $id = mysqli_real_escape_string($conn, $_REQUEST['id']);
    $sql = "SELECT * FROM `topic` WHERE `id`='$id'";
    $result = mysqli_query($conn, $sql);

    $row = mysqli_fetch_array($result);
  }

  // Check for submit
  if (filter_has_var(INPUT_POST, 'submit')){
    // Get form data
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $username = mysqli_real_escape_string($conn, $_POST['name']);
    $question = mysqli_real_escape_string($conn, $_POST['question']);
    $topics = mysqli_real_escape_string($conn, $_POST['topics']);

    // Check required fields
    if (!empty($id) && !empty($username) && !empty($question) && !empty($topics)){

      // Insert user into database
      $sql = "UPDATE `topic` SET id='$id', name='$username', question='$question', topics='$topics' WHERE id='$id'";

      if (mysqli_query($conn, $sql)){
        $msg = "Update Successfull";
        $msgClass = "green";
      } else {
        $msg = "Update error: " . $sql . "<br>" . mysqli_error($conn);
        $msgClass = "red";
      }
    } else {
      // failed
      $msg = "Please fill in all fields";
      $msgClass = "red";
    }
  }

  mysqli_close($conn);
?>
<div class="wrapper">
  <section class="section">
    <div class="container2">
      <?php if($msg != ''): ?>
        <div id="msgBox" class="card-panel <?php echo $msgClass; ?>">
          <span class="white-text"><?php echo $msg; ?></span>
        </div>
      <?php endif ?>
      <h5><div class="card-panel blue darken-3 white-text">
      <i class="fas fa-edit"></i> Edit record <span class="blue-text"><?php echo $row['id']; ?></span></h5>
      <div class="divider"></div><br><br>

      <!-- Locker edit form  -->
      <form class="col s12" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" novalidate>
        <div class="row">
          <div class="input-field">
            <i class="material-icons prefix">credit_card</i>
            <input type="text" id="id" name="id" value="<?php echo $row['id']; ?>">
            <label for="id">Admin Id</label>
          </div>
        </div>
        <div class="row">
          <div class="input-field">
            <i class="material-icons prefix">face</i>
            <input type="text" id="uname" name="username" value="<?php echo $row['name']; ?>">
            <label for="uname">Username</label>
          </div>
        </div>
        <div class="row">
          <div class="input-field">
            <i class="material-icons prefix">email</i>
            <input type="text" id="question" name="question" value="<?php echo $row['question']; ?>">
            <label for="question">Email</label>
          </div>
        </div>
        <div class="row">
          <div class="input-field">
            <i class="material-icons prefix">local_phone</i>
            <input type="text" id="topics" name="topics" value="<?php echo $row['topics']; ?>">
            <label for="topics">Phone</label>
          </div>
        </div>
        <div class="row">
          <div class="center">
            <button type="submit" class="waves-effect waves-light btn blue" name="submit">Update</button>
          </div>
        </div>
      </form>
    </div>
  </section>
</div>
<?php
  include 'footer.php';
?>
