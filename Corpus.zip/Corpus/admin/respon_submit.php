<?php  
session_start();
require '../model/db.php';

$commentID = $_POST['commentID'];
$respondate = $_POST['respondate'];
$userID = $_POST['userID'];
$respon = $_POST['respon'];

if(!empty($respon) && !empty($commentID)) {
	$sql = "INSERT INTO comment_respon (commentID, userID, respondate, respon) 
		    VALUES ('$commentID', '$userID', '$respondate', '$respon')";

	if (mysqli_query($conn, $sql)) 
			{ 	
				$sql = "UPDATE comment SET status='read' WHERE commentID='$commentID'";

				if (mysqli_query($conn, $sql)) {
				   $_SESSION['msg'] = "data successfully saved.  ";
		   			header ("Location: comment.php");
				} else {
				    echo "Error updating record: " . mysqli_error($conn);
				}
				
			} 
			else 
			{
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}    
} else {
	$_SESSION['msg'] = "Sila Lengkapkan Butiran";
	header("Location : comment.php");
}

mysqli_close($conn);
?>