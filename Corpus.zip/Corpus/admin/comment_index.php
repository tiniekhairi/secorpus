<?php
  //session_start();
  //require 'session.php';
  include 'navbar.php';
  require '../model/db.php';

  $msg = $msgClass = '';
  
    $sql = "SELECT *, COUNT(*) AS commentbadget FROM comment WHERE status = 'unread'";
    $result = mysqli_query($conn, $sql);
    mysqli_num_rows($result);
    $row = mysqli_fetch_assoc($result);

?>

<div class="wrapper">
  <section class="section">
    <div class="container2">
      <?php if($msg != ''): ?>
        <div id="msgBox" class="card-panel <?php echo $msgClass; ?>">
          <span class="white-text"><?php echo $msg; ?></span>
        </div>
      <?php endif ?>
	  
      <center><h5><div class="card-panel grey darken-3 white-text">
      <i class="fas fa-book"></i> <b>Quiz & Comment</b> </h5></center>
      <div class="divider"></div>
      
      <br>
	  <br>

<body>
<center><a href="comment.php"><button class="waves-effect waves-light btn blue" >Comments to be replied : <span class="badge"><?php echo $row['commentbadget'];?></span></button></a></center>	
</body>
</section>
</div>

<?php
  mysqli_close($conn);
  include 'footer.php';
?>
