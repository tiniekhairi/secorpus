<?php
  session_start();
  //require 'session.php';
  include 'navbar.php';
  require '../model/db.php';
  //TIMEZONE MALAYSIA
  date_default_timezone_set("Asia/kuala_lumpur"); 
  if (isset($_SESSION['msg'])) {
     $msg = $_SESSION['msg'] ;
  }
 
  echo $userID = $_REQUEST['userID'];

?>

<div class="wrapper">
  <section class="section">
    <div class="container2">
      <?php if(!empty($msg)){ ?>
        <div id="msgBox" class="card-panel <?php echo $msgClass; ?>">
          <span class="white-text"><?php echo $msg; ?></span>
        </div>
      <?php unset($_SESSION['MSG']); }?>
      <center><h5><div class="card-panel grey darken-3 white-text">
      <i class="fas fa-comment"></i> Comment </h5></center>
      <div class="divider"></div>
   
			<br>
			<br>
		
	       <div class="card">
          <div class="card-content">
            
            <b><span class="card-title center-align"><b>User Comment</b></span></b>
            <div class="row">
            <br>
              <div class="panel panel-default">
                        <div class="panel-heading">
                            <!-- DataTables Advanced Tables -->
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th><center>No.</center></th>
                                        <th><center>User ID</center></th>
                                        <th><center>Date & Time</center></th>
                                        <th><center>Your Comment</center></th>
                                        <th><center>Answered</center></th>
                                    </tr>
                                </thead>
                                <?php 
                                  $sql = "SELECT * FROM comment_respon WHERE userID = '$userID'";
                                  $result = mysqli_query($conn, $sql);
                                   if (mysqli_num_rows($result) > 0) {
                                      //set counter variable 
                                      $counter = 1;
                                      // output data of each row
                                      while($row = mysqli_fetch_assoc($result)) { 
                                ?>
                                <tbody>
                                  <tr>
                                    <td><center><?php echo $counter ?></center></td>
                                    <td><center><?php echo $row['userID'] ?></center></td>
                                    <td><center><?php echo $row['respondate'] ?></center></td>
                                    <td><a href="comment_respon.php?commentID=<?php echo $row['commentID']; ?>"><center><button class="waves-effect waves-light btn blue"><i class="fas fa-edit"></i></button></center></a></td>
									<td><center><?php echo $row['respon'] ?></center></td>
								  </tr>
                                </tbody>
                                <?php
                                //increment counter by 1 on every pass 
                                $counter++;
                                      }
                                  } else {
                                      echo "0 results";
                                  }         
                                ?>
                                
                            </table>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->

            </div>
          </div>
        </div>
      
<?php
  mysqli_close($conn);
  include 'footer.php';
?>
