<div class="wrapper">
  <nav class="blue">
    <div class="nav-wrapper">
      <a href="#" class="brand-logo center-align">&nbsp Spec Corpus Final Exam SE</a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="login.php" class="btn-flat white-text">Login</a></li>
      </ul>
      <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>
    </div>
  </nav>
</div>