<?php
  //session_start();
  //require 'session.php';
  include 'navbar.php';
  require '../model/db.php';
?>
<div class="wrapper">
<section class="section">
  <div class="container2">
  <h5><div class="card-panel grey darken-3 white-text">
    <i class="fas fa-box"></i> About Us</h5>
    <div class="divider"></div><br>
        </div>
        <div class="container2 center">
        <div class="row">
          <ul class="collection with-header z-depth-1">
            <li class="collection-header grey darken-3 white-text">
              <i class="fas fa-map-marker"></i> Contact us
            </li>
            <li>
              <img class="responsive-img" src="contact_us.jpeg" alt="contact">
            </li>
            <li>
              <p style="padding:0 1em;">
                Universiti Teknikal Malaysia Melaka,<br>
                Hang Tuah Jaya, 76100 Durian Tunggal,<br>
                Melaka, Malaysia.<br><br>
                <i class="fas fa-phone"></i>&nbsp;&nbsp;+606 555 2000<br>
                <i class="fas fa-phone"></i>&nbsp;&nbsp;+606 331 6247<br>
                <i class="fas fa-envelope"></i>&nbsp;&nbsp;<a href="#">webmaster@utem.edu.my</a>
              </p>
            </li>
          </ul>
  <div class="container2 center">
        <div class="row">
          <ul class="collection with-header z-depth-1">
            <li class="collection-header grey darken-3 white-text">
              <i class="fas fa-map-marker"></i> Policies and Regulation</li>
            <li>
              <p style="padding:0 1em;">
              Our policies, regulations and other public documents are listed in alphabetical order below. All available documents are just for review purpose and plagiarize is forbidden. Regulations and policies may be initiated in one of the University's departments or committees, but all regulations and policies must be agreed formally. Please contact Faculty of Information Technology and Communication (FTMK) of Universiti Teknikal Malaysia Melaka (UTeM) for further information..<br><br>
              </p>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  </div>  </div>
  </div>  </div>
        </div>
      </div>
    </div>
  
</section>
<?php
  include 'footer.php';
?>
