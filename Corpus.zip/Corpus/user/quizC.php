<?php
   session_start();
   //require 'session.php';
   include 'navbar.php';
   require '../model/db.php';
   
   $msg = $msgClass = '';

 if(isset($_POST['start']))
 {
 	$_SESSION['start'] = 1+10;
 	$_SESSION['question'] = 1+10;
 } 

  if(isset($_POST['click']))
 {
 	$id = $_POST['id'];
 	$sql = mysqli_query($conn,"SELECT * 	FROM quiz WHERE id = '$id'");
    $row = $sql->fetch_assoc();

    $userans = $_POST['userans'];

    if($userans == $row['ans']){
    	//echo "<script> alert('betul') </script>";	
    	$mark = $_SESSION['mark'];
    	$q = $_SESSION['question'];
    	$q = $q + 1;
    	$mark = $mark + 1;
    	$_SESSION['mark'] = $mark;
    	$_SESSION['question'] = $q;
	}else
	{
		//echo "<script> alert('salah') </script>";
		$q = $_SESSION['question'];
    	$q = $q + 1;	
    	$_SESSION['question'] = $q;
	}
 	

 } 

   if(isset($_POST['finish']))
 {
 	$id = $_POST['id'];
 	$sql = mysqli_query($conn,"SELECT * 	FROM quiz WHERE id = '$id'");
    $row = $sql->fetch_assoc();

    $userans = $_POST['userans'];

    if($userans == $row['ans']){
    	//echo "<script> alert('betul') </script>";	
    	$mark = $_SESSION['mark'];
    	$mark = $mark + 1;
    	$_SESSION['mark'] = $mark;
	}else
	{
		//echo "<script> alert('salah') </script>";
	}
 	$_SESSION['finish'] = 1+10;
 }	
   ?>
<div class="wrapper">
<section class="section">
<div class="container2">
<?php if($msg != ''): ?>
<div id="msgBox" class="card-panel <?php echo $msgClass; ?>">
   <span class="white-text"><?php echo $msg; ?></span>
</div>
<?php endif ?>
<h5>
   <div class="card-panel grey darken-3 white-text">
   <i class="fas fa-book"></i> Quiz 
</h5>
<div class="divider"></div>
<br>
<body>
   <center>
      <div id="page-wrap">
      <div class="title"></div>
      <div class="bump">
         <br>
     <?php if($_SESSION['finish'] == 1+10){ ?>
     <h1>Total Mark: <?php echo $_SESSION['mark'] ?></h1>
     
     <div style='text-align:left'>
     <?php
      for($i=11;$i<16;$i++)
     {
      $sql = mysqli_query($conn,"SELECT que , ans FROM quiz WHERE id ='$i'");
        $row = $sql->fetch_assoc();
        echo "<br>".$i.". "."<h6>".$row["que"]."</h6>";
        echo "<h8><b>"."Correct answer : ".$row["ans"]."</b></h8>";
      }
     ?>     
  <br>
  <br>

     <center><a class="button" href="quizCstart.php?fn=end" float="left"><span>Finish</span></a></center>
 	 <?php }else { ?>
     <?php if($_SESSION['start'] == 0+10){ ?>
         <form method="post">
            <center>
               <h6>Answer all question</h6>
            </center>
            <button class="button" name="start" float="left"><span>START QUIZ</span></button>
         </form>
     <?php } ?>
      </div>
     
     <?php if($_SESSION['start'] == 1+10 && $_SESSION['question'] <= 5+10){ ?>
      <form method="post">
      	<?php 
      		$sql = mysqli_query($conn,"SELECT * 	FROM quiz WHERE id = '".$_SESSION['question']."'");
      		$row = $sql->fetch_assoc();
      	?>
        <div style='text-align:left'>
      	<h5><?php echo $row['que']; ?></h5>
         <td class="left" align="left">
            <div>
             <input hidden type="number" name="id" value="<?php echo $_SESSION['question']; ?>" />
               <input required type="radio" name="userans" id="1" value="<?php echo $row['option1']; ?>" />
               <label for="1"><?php echo $row['option1']; ?></label>
               <br>
            </div>
            <div>
               <div>
                  <input required type="radio" name="userans" id="2" value="<?php echo $row['option2']; ?>" />
                  <label for="2"><?php echo $row['option2']; ?></label>
                  <br>
               </div>
               <div>
                  <input required type="radio" name="userans" id="3" value="<?php echo $row['option3']; ?>" />
                  <label for="3"><?php echo $row['option3']; ?></label>
                  <br>
               </div>
               <div>
                  <input required type="radio" name="userans" id="4" value="<?php echo $row['option4']; ?>" />
                  <label for="4"><?php echo $row['option4']; ?></label>
                  <br>
               </div>
               <br>
               <br>
               <br>
               <?php if($_SESSION['question'] != 5+10){ ?><center>
               <button class="button3" name="click" >Next</button></center>
               <?php }else { ?> 
               <center><button class="button3" name="finish" >Finish</button></center>
               <?php } ?>
         </td>
      </form>
     <?php } ?>
     <?php } ?>
   </center>
</body>
</div>
<?php
   mysqli_close($conn);
   include 'footer.php';
   ?>