<?php
  session_start();
  //require 'session.php';
  include 'navbar.php';
  require '../model/db.php';

  $msg = $msgClass = '';
?>

<div class="wrapper">
  <section class="section">
    <div class="container2">
      <?php if($msg != ''): ?>
        <div id="msgBox" class="card-panel <?php echo $msgClass; ?>">
          <span class="white-text"><?php echo $msg; ?></span>
        </div>
      <?php endif ?>
      <center><h5><div class="card-panel grey darken-3 white-text">
      <i class="fas fa-book"></i><b> Comment </b></h5></center>
      <div class="divider"></div>
      
	  <br>
	  <br>

	  
<body>
  <!--?php print_r($_SESSION) ?-->

<center><a href="comment.php"><button class="waves-effect waves-light btn blue" >comment</button></a></center>
<?php
    if (!empty($_SESSION['s_id'])) {
      $userID = $_SESSION['s_id'];
    $sql = "SELECT * FROM comment WHERE userID = '$userID'";
    $result = mysqli_query($conn, $sql);
    mysqli_num_rows($result);
    $row = mysqli_fetch_assoc($result);

    if ($row['status']='read'){ ?>
  <br><center><a href="comment_list.php?userID=<?php echo $row['userID'] ?>"<button class="waves-effect waves-light btn blue" >Comment Feedback</button></a></center><br>
    <?php }} ?>
     
    

	
	<script type="text/javascript">
	var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
	document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
	</script>
	<script type="text/javascript">
	var pageTracker = _gat._getTracker("UA-68528-29");
	pageTracker._initData();
	pageTracker._trackPageview();
	</script>

</body>
  </section>
</div>

<?php
  mysqli_close($conn);
  include 'footer.php';
?>
