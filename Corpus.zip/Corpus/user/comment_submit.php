<?php  
session_start();
require '../model/db.php';

$adminID = '111113';

echo $userID = $_POST['userID'];
echo $commlist = $_POST['commlist'];
echo $commdate = $_POST['commdate'];
echo $status = $_POST['status'];

if (!empty($userID) && !empty($commlist)) {
	$sql = "INSERT INTO comment (adminID, userID, commlist, status, commdate) 
			VALUES ('$adminID', '$userID', '$commlist', '$status', '$commdate')";
	if (mysqli_query($conn, $sql)) 
			{ 	
				$_SESSION['MSG'] = "data successfully saved.  ";
		   		header ("Location: comment.php");
			} 
			else 
			{
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}    
} else {
	$_SESSION['MSG'] = "Sila Lengkapkan Butiran";
	header("Location : comment.php");
}
mysqli_close($conn);
?>