<?php
   session_start();
  
  if($_GET['fn'] == "start")
  { 
   $_SESSION['mark'] = 0;
   $_SESSION['start'] = 0;
   $_SESSION['question'] = 0;
   $_SESSION['finish'] = 0;

   echo "<script> window.location.href = 'quizA.php' </script>";
  }elseif($_GET['fn'] == "end")
  {
     $_SESSION['mark'] = 0;
     $_SESSION['start'] = 0;
     $_SESSION['question'] = 0;
     $_SESSION['finish'] = 0;

    echo "<script> window.location.href = 'quiz1user.php' </script>";
  }
?>
