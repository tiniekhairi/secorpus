<?php
  session_start();
  //require 'session.php';
  include 'navbar.php';
  require '../model/db.php';
  //TIMEZONE MALAYSIA
  date_default_timezone_set("Asia/kuala_lumpur");

  $msg = $msgClass = '';
  $commentID = $_REQUEST['commentID'];
  $userID = $_SESSION['s_id'];         	
?>

<div class="wrapper">
  <section class="section">
    <div class="container2">
      <?php if($msg != ''): ?>
        <div id="msgBox" class="card-panel <?php echo $msgClass; ?>">
          <span class="white-text"><?php echo $msg; ?></span>
        </div>
      <?php endif ?>
      <center><h5><div class="card-panel grey darken-3 white-text">
      <i class="fas fa-comment"></i> Comment </h5></center>
      <div class="divider"></div>

        <?php 
          $sql = "SELECT * FROM comment WHERE userID = '$userID' AND commentID = '$commentID'";
          $result = mysqli_query($conn, $sql);
          if (mysqli_num_rows($result) > 0) {
          //set counter variable 
          $counter = 1;
          // output data of each row
          while($row = mysqli_fetch_assoc($result)) { 
          ?>
          <div class="card">
            <div class="card-content">
              <b><span class="card-title center-align">User Comment</span></b>
              <div class="row">
                <div class="col-lg-6">
                    <label for="userID">User ID</label>
                    <input type="text" id="userID" value="<?php echo $row['userID'] ?>" readonly>
                    <textarea readonly><?php echo $row['commlist'] ?></textarea>
                </div>
              </div>
			  
			   <div class="row">
                  <p class="center-align">
				  <a href="comment_list.php?userID=b031710089">
               <button type="submit" class="waves-effect waves-light btn blue" name="submit">Done</button>
                  </p>
              </div>
			  
            </div>
          </div>
          
      <?php 
          }
        }
      ?>

<?php
  mysqli_close($conn);
  include 'footer.php';
?>
