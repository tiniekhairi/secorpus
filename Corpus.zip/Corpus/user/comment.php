<?php
  session_start();

  //require 'session.php';
  include 'navbar.php';
  require '../model/db.php';
  $msg = $msgClass = '';
  date_default_timezone_set("Asia/kuala_lumpur");
  	
   
  $sql1 = "select * from admin";
  $query1=mysqli_query($conn,$sql1);
  mysqli_close($conn);
  include 'footer.php';
?>

<div class="wrapper">
  <section class="section">
    <div class="container2">
      <?php if($msg != ''): ?>
        <div id="msgBox" class="card-panel <?php echo $msgClass; ?>">
          <span class="white-text"><?php echo $msg; ?></span>
        </div>
      <?php endif ?>
      <center><h5><div class="card-panel grey darken-3 white-text"><i class="fas fa-comment"></i><b>Comment</b></h5></center>
      <hr>
      <br>

        <div class="card">
          <div class="card-content">
            <span class="card-title center-align">Kindly Drop Your Comment Here :</span>
              <div class="row">
                <form method="POST" action="comment_submit.php" novalidate>
                    <div class="row">
                      <div class="input-field">  
                        <i class="material-icons prefix">question_answer</i>
						<label for="userID" >User id</label>
						<input type="text" id="userID" name="userID">
						</div>
						 
                         
						  <textarea name="commlist" rows="100" cols="100"></textarea>
                          <input type="hidden" class="form-control" name="commdate" id="date/time" value="<?php echo date("Y-m-d h:i:sa") ?>">
                          <input type="hidden" name="status" value="unread">
                      </div>
                    </div>
                                 
                                  <div class="row">
                                    <p class="center-align">
                                      <button type="submit" class="waves-effect waves-light btn blue" name="submit">Comment !</button>
                                    </p>
                                  </div>
                                </form>
            </div>
            </div>
</div>
