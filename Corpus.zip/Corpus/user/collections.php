<?php
  //include './header.php';
  include './navbar.php';
  //include './sidenav.php';
  //require 'session.php';
  include '../model/db.php';

     // Save file
  if (isset($_POST['save'])) {
    // use session
    // $user_ud = $_SESSION['u_id'];
    $user_id = '1';
    $doc_id = mysqli_real_escape_string($conn, $_POST['doc_id']);
    $query = mysqli_query($conn, "SELECT * FROM `favourite` WHERE `user_id`=$user_id AND `doc_id`=$doc_id");
    $sql = "INSERT INTO `favourite` (`user_id`, `doc_id`, `date`)
            VALUE ('$user_id', '$doc_id', CURRENT_TIMESTAMP)";

    if (mysqli_num_rows($query) > 0){
      echo "
      <script>
        $(function(){
          M.toast({html: 'Data exist'})
        });  
      </script>";
    } else {
      if ($conn->query($sql) === TRUE) {
        echo "
        <script>
          $(function(){
            M.toast({html: 'Save completed'})
          });  
        </script>";
      } else {
        echo "
        <script>
          $(function(){
            M.toast({html: 'Error while saving!'})
          });  
        </script>";
      }
    }

  }
  
  // $con->close();
?>
  <div class="wrapper">
  <section class="section">
    <div class="container2">
    <h5><div class="card-panel grey darken-3 white-text">
      <i class="fas fa-book"></i> Document Collection</h5>
      <div class="divider"></div>
      <div class="row">
        <div class="col s12 m6"></div>
        <div class="col s12 m6">
          <input id="search" placeholder="Search File" type="text">
        </div>
      </div>
      <br>

      <table id="myTable" class="highlight">
        <thead class="blue white-text">
          <tr class="myHead">
            <th>#</th>
            <th>Name</th>
            <th>Year</th>
            <th>Date Upload</th>
            <th>Created by</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php 
            $i = 1;
            $sql = "SELECT * FROM `document`";
            $result = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_array($result)):
          ?>
            <tr>
              <td><?php echo $i; $i++; ?></td>
              <td><a href="<?php echo $row['path']; ?>" target="_blank"><?php echo $row['name']; ?></a></td>
              <td><?php echo $row['year']; ?></td>
              <td><?php echo $row['date']; ?></td>
              <td><?php echo $row['createby']; ?></td>
              <td>
                <form action="" method="POST">
                  <input type="hidden" name="doc_id" value="<?php echo $row['id']; ?>">
                  <button type="submit" name="save" class="btn-flat">save</button>
                </form>
              </td>
            </tr>
          <?php endwhile ?>
        </tbody>
      </table>
    </div>
  </div>


<?php 
  include './footer.php';
?>