<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Home</title>
  <link rel="stylesheet" href="css/materialize.min.css">
  <script src="js/fontawesome-all.min.js"></script>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <script src="js/jquery-3.3.1.min.js"></script>
  <link rel="stylesheet" href="css/style.css">
</head>
<body background="img/papan2.jpg">

    <div class="center card-panel indigo darken-1 white-text">
    <h5><a id="logo-container" href="#" class="brand-logo">
        <img class="logo-img" src="img/selogo.png" alt="logo"></a></ul>
        <b>   Software Engineering Corpus System</b></h5></div>
      <div class="divider"></div><br></a>

      </ul>
    </div>
  </nav>
